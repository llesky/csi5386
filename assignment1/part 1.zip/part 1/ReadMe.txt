Usage:

programming language: python 3.6

part 1 used external library of python: spacy, nltk.

install: pip3 install spcay
	 pip 3 install nltk 

Running: python task1.py
you must add two initial file to run it, "microblog2011.txt" "StopWords.txt"

result: 
section A: microblog2011_tokenized.txt is created, top 20 will print formally.
section B: print the number of tokens, the types of tokens and ratio.
section C: Tokens.txt is created.
section D: print number of words that only show once.
section E: E.txt is created, top 100 print formally.
section F: F.txt is created, top 100 print formally.
section G: G.txt is created, top 100 print formally.

note: section A create microblog2011_tokenized.txt will take long time. other step is fairly short.